<?php
/**
 * Polyfill WP_HTML_Tag_Processor.
 *
 * @package wp-directives
 */

if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
	require __DIR__ . '/../../../gutenberg/lib/compat/wordpress-6.2/html-api/class-wp-html-attribute-token.php';
	require __DIR__ . '/../../../gutenberg/lib/compat/wordpress-6.2/html-api/class-wp-html-span.php';
	require __DIR__ . '/../../../gutenberg/lib/compat/wordpress-6.2/html-api/class-wp-html-text-replacement.php';
	require __DIR__ . '/../../../gutenberg/lib/compat/wordpress-6.2/html-api/class-wp-html-tag-processor.php';
}
