export const csnMetaTagItemprop = 'wp-client-side-navigation';
export const componentPrefix = 'wp-';
export const directivePrefix = 'data-wp-';
