<?php return array('dependencies' => array(), 'version' => '8ff3477eebdb6c7f40ea');
