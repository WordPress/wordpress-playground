/**
 * MySQL server init.
 *
 * SQL queries in this file will be executed the first time the MySQL server is started.
 */

CREATE DATABASE IF NOT EXISTS wordpress_develop;
CREATE DATABASE IF NOT EXISTS wordpress_develop_tests;
