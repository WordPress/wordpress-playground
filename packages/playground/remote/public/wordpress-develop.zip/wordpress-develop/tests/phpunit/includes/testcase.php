<?php
/**
 * Basic abstract test class.
 *
 * All WordPress unit tests should inherit from this class.
 */
abstract class WP_UnitTestCase extends WP_UnitTestCase_Base {}
