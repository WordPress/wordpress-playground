window.wp = window.wp || {};
window.wp.customize = window.wp.customize || { get: function(){}  };
window._wpCustomizeHeader = {};
window._wpCustomizeHeader.uploads = {
	'cropped-abstract_00601126.jpg': {
		'attachment_id': 1,
		'url': 'http://dev.local/2013/11/cropped-abstract_00601126.jpg',
		'thumbnail_url': 'http://dev.local/2013/11/cropped-abstract_00601126.jpg',
		'width': 1600,
		'height': 230,
		'timestamp': 1385045565
	},
	'cropped-cropped-miniature-golden-retriever-puppies-for-sale01127.jpg': {
		'attachment_id': 2,
		'url': 'http://dev.local/2013/11/cropped-cropped-miniature-golden-retriever-puppies-for-sale01127.jpg',
		'thumbnail_url': 'http://dev.local/2013/11/cropped-cropped-miniature-golden-retriever-puppies-for-sale01127.jpg',
		'width': 1600,
		'height': 230,
		'timestamp': 1385045566
	},
	'cropped-tumblr_m20paq9cjn1qbkdcro1_5003.png': {
		'attachment_id': 3,
		'url': 'http://dev.local/2013/11/cropped-tumblr_m20paq9cjn1qbkdcro1_5003.png',
		'thumbnail_url': 'http://dev.local/2013/11/cropped-tumblr_m20paq9cjn1qbkdcro1_5003.png',
		'width': 1600,
		'height': 230,
		'timestamp': 1385045567
	}
};
window._wpCustomizeHeader.defaults = {
	'circle': {
		'url': 'https://dev.local/wp-content/themes/pub/twentythirteen/images/headers/circle.png',
		'thumbnail_url': 'https://dev.local/wp-content/themes/pub/twentythirteen/images/headers/circle-thumbnail.png',
		'description': 'Circle'
	},
	'diamond': {
		'url': 'https://dev.local/wp-content/themes/pub/twentythirteen/images/headers/diamond.png',
		'thumbnail_url': 'https://dev.local/wp-content/themes/pub/twentythirteen/images/headers/diamond-thumbnail.png',
		'description': 'Diamond'
	},
	'star': {
		'url': 'https://dev.local/wp-content/themes/pub/twentythirteen/images/headers/star.png',
		'thumbnail_url': 'https://dev.local/wp-content/themes/pub/twentythirteen/images/headers/star-thumbnail.png',
		'description': 'Star'
	}
};
