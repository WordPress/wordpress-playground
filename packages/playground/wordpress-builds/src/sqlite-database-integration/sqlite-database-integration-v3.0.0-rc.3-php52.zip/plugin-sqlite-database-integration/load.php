<?php

/**
 * Plugin Name: SQLite Database Integration
 * Description: SQLite database driver drop-in.
 * Author: The WordPress Team
 * Version: 3.0.0-rc.3
 * Requires PHP: 7.2
 * Textdomain: sqlite-database-integration
 *
 * This feature plugin allows WordPress to use SQLite instead of MySQL as its database.
 *
 * @package wp-sqlite-integration
 */
/**
 * Load the "SQLITE_DRIVER_VERSION" constant.
 * This constant needs to be updated on plugin release!
 */
require_once dirname(__FILE__) . '/wp-includes/database/version.php';
define('SQLITE_MAIN_FILE', __FILE__);
require_once dirname(__FILE__) . '/admin-page.php';
require_once dirname(__FILE__) . '/activate.php';
require_once dirname(__FILE__) . '/deactivate.php';
require_once dirname(__FILE__) . '/admin-notices.php';
require_once dirname(__FILE__) . '/health-check.php';
if (!function_exists('_pg52_at')) {
    function _pg52_at($arr, $idx)
    {
        return is_array($arr) && array_key_exists($idx, $arr) ? $arr[$idx] : null;
    }
    function _pg52_call($obj, $method, $args)
    {
        return call_user_func_array(array($obj, $method), $args);
    }
    function _pg52_get($obj, $prop)
    {
        return $obj->{$prop};
    }
}
