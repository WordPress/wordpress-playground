// PHP.wasm requires WordPress Playground's Node polyfills.
import '@php-wasm/node-polyfills';

export * from './lib';
