/**
 * A dummy entrypoint is needed for the @nx/esbuild:esbuild
 * to work properly. See https://github.com/nrwl/nx/pull/14636/files
 */
